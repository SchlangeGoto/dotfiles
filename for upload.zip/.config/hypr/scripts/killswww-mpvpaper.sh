#!/bin/bash
killall mpvpaper

